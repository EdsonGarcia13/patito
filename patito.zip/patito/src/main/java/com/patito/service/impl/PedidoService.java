package com.patito.service.impl;

import com.patito.entities.Pedido;
import com.patito.entities.Producto;
import com.patito.repository.PedidoRepository;
import com.patito.repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

@Service
public class PedidoService {
    @Autowired
    private PedidoRepository pedidoRepository;
    @Autowired
    private ProductoRepository productoRepository;

    public void agregarPedido(Pedido pedido) {
        Producto producto = productoRepository.findByIdentificadorHAWA(pedido.getIdentificadorHAWA());
        if (producto != null && producto.getExistencias() > 0) {
            pedido.setEstatusPedido("pendiente");
            pedidoRepository.save(pedido);
        }
    }

    public List<Pedido> obtenerPedidos() {
        return pedidoRepository.findAllByOrderByFechaEventoDesc();
    }

    public void cambiarEstatusPedido(Long idPedido, String nuevoEstatus) {
        Optional<Pedido> optionalPedido = pedidoRepository.findById(idPedido);
        if (optionalPedido.isPresent()) {
            Pedido pedido = optionalPedido.get();
            if (pedido.getEstatusPedido().equals("pendiente") && nuevoEstatus.equals("entregado")) {
                pedido.setEstatusPedido(nuevoEstatus);
                pedidoRepository.save(pedido);
            } else if (pedido.getEstatusPedido().equals("pendiente") && nuevoEstatus.equals("cancelado")) {
                LocalDateTime fechaActual = LocalDateTime.now();
                LocalDateTime fechaCreacionPedido = pedido.getFechaEvento();
                long minutosTranscurridos = ChronoUnit.MINUTES.between(fechaCreacionPedido, fechaActual);
                if (minutosTranscurridos <= 10) {
                    pedido.setEstatusPedido(nuevoEstatus);
                    pedidoRepository.save(pedido);
                }
            }
        }
    }
}