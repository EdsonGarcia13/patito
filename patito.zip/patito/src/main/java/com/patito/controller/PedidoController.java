package com.patito.controller;


import com.patito.entities.Pedido;
import com.patito.service.impl.PedidoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class PedidoController {
    @Autowired
    private PedidoService pedidoService;

    @PostMapping("/agregar-pedido")
    public ResponseEntity<String> agregarPedido(@ModelAttribute Pedido pedido) {
        pedidoService.agregarPedido(pedido);
        return ResponseEntity.ok("Pedido agregado correctamente");
    }

    @GetMapping("/listar-pedidos")
    public ResponseEntity<List<Pedido>> listarPedidos() {
        List<Pedido> pedidos = pedidoService.obtenerPedidos();
        return ResponseEntity.ok(pedidos);
    }

    @PostMapping("/cambiar-estatus-pedido")
    public ResponseEntity<String> cambiarEstatusPedido(@RequestParam Long idPedido, @RequestParam String nuevoEstatus) {
        pedidoService.cambiarEstatusPedido(idPedido, nuevoEstatus);
        return ResponseEntity.ok("Estatus del pedido actualizado correctamente");
    }
}
