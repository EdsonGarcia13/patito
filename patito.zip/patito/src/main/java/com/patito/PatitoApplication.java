package com.patito;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatitoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatitoApplication.class, args);
	}

}
