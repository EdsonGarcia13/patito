package com.patito.entities;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "pedido")
public class Producto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = true)
    @Column(name = "idHawa")
    private String idHAWA;
    private Double precioLista;
    private Double descuento;
    private Integer existencias;
}
