package com.patito.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Setter
@Getter
@Entity
@Table(name = "pedido")
public class Pedido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = true)
    @Column(name = "id")
    private Long id;
    private LocalDateTime fechaEvento;
    private String ipUsuario;
    private String identificadorHAWA;
    private String identificadorTienda;
    private String datosBasicosCliente;
    private String nombreVendedor;
    private Double descuentoProducto;
    private String estatusPedido;
}
